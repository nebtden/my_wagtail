<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\1\17 0017
 * Time: 15:55
 */

namespace frontend\controllers;


use common\models\Product;
use common\models\Product_complain;
use common\models\Product_detail;
use common\models\Scene;
use Yii;

class ProductController extends BaseController
{
    public $site_title = '云车';

    public function actionIndex()
    {
        $num = 3;
        //产品中心
        $productList = (new Product())->getData('id,title,pic,pic_gray,en_lang,sub_title,active', 'all', ' is_del=0 and type=0', ' sort desc');
        $len = ceil(count($productList) / $num);
        $productListRes = array();
        for ($i = 0; $i < $len; $i++) {
            for ($j = 0; $j < $num; $j++) {
                if ($i * $num + $j >= count($productList)) {
                    break;
                }
                $productListRes[$i][$j] = $productList[$i * $num + $j];
            }
        }
        //应用场景
        $sceneList = (new Scene())->getData('id,title,product,obj', 'all', ' is_del=0', ' sort desc', ' 3');
        return $this->renderPartial('index', [
            'productList' => $productListRes,
            'sceneList' => $sceneList,
        ]);
    }

    public function actionProdetail()
    {
        $id = Yii::$app->request->get('id', 0);
        $prodectDetail = (new Product_detail())->getData('*', 'one', ' is_del=0 and pid = ' . $id);
        //客诉
        $complainList = (new Product_complain())->getData('*', 'all', ' is_del=0 and (pid=0 or pid = ' . $id . ')',' sort desc',' 3');
        //产品中心
        $productList = (new Product())->getData('id,title,pic,pic_home,en_lang', 'all', ' is_del=0 and type=0 and active=1 and id!=' . $id, ' sort desc', ' 6');
        //应用场景
        $sceneList = (new Scene())->getData('title,product,obj', 'all', ' is_del=0', ' sort desc', ' 3');
        return $this->renderPartial('product_detail', [
            'sceneList' => $sceneList,
            'productList' => $productList,
            'prodectDetail' => $prodectDetail,
            'complainList' => $complainList,
        ]);
    }
}