<?php

use yii\helpers\Html;
use yii\helpers\Url;

?>

<?php $this->beginPage() ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo $this->context->site_title; ?></title>
    <link rel="stylesheet" href="<?= CSS_URL ?>/public.css"/>
    <link rel="stylesheet" href="<?= CSS_URL ?>/bootstrap.min.css">
    <link rel="stylesheet" href="<?= CSS_URL ?>/cloudsCar.css"/>
    <link rel="stylesheet" href="<?= CSS_URL ?>/swiper.min.css"/>
    <script src="<?= JS_URL ?>/jquery-2.1.4.js"></script>
    <script src="<?= JS_URL ?>/bootstrap.min.js"></script>
    <script src="<?= JS_URL ?>/swiper.min.js"></script>
</head>
<style>
    .swiper-pagination-bullet {
        width: 12px;
        height: 12px;
        background-color: rgba(0, 0, 0, 0);
        border: 1px solid #fff;
        border-radius: 10px;
        opacity: .44;
    }

    .swiper-pagination-bullet-active {
        background-color: #fff;
    }

    .swiper-button-prev {
        left: 26%;
    }

    .swiper-button-next {
        right: 26%;
    }
</style>
<body>
<?php $this->beginBody() ?>
<div class="system-banner">
    <img src="<?= STATIC_URL . $prodectDetail['banner_img'] ?>">
    <div class="banner-wrap">
        <p><?= $prodectDetail['title'] ?></p>
        <img src="<?= IMG_URL ?>/yc-float.png">
    </div>
</div>
<div class="system-item-wrap">
    <div class="system-item-box">
        <h2>服务标准</h2>
        <div class="sys-item-content">
            <h3><i><img src="<?= IMG_URL ?>/yc-partner-symbol.png"></i>服务内容：</h3>
            <?= $prodectDetail['service_content'] ?>
        </div>
        <div class="sys-item-content">
            <h3><i><img src="<?= IMG_URL ?>/yc-partner-symbol.png"></i>服务标准：</h3>
            <p>
                <?= $prodectDetail['service_standard'] ?>
            </p>
        </div>
    </div>
</div>
<div class="sys-area-wrap">
    <img src="<?= IMG_URL ?>/yc-system-item-bg.jpg">
    <div class="banner-wrap load-wrap">
        <p>覆盖区域</p>
        <p>详细覆盖区域请下载附件</p>
        <button class="common-btn load-btn"><span class="glyphicon glyphicon-download-alt"></span>点击下载附件</button>
    </div>
</div>
<div class="system-item-wrap">
    <div class="system-item-box">
        <h2>服务承诺</h2>
        <div class="sys-item-content">
            <p>
                <?= $prodectDetail['service_promises'] ?>
            </p>
        </div>
    </div>
</div>
<div class="sys-swiper-wrap">
    <h2>客诉</h2>
    <div class="swiper-container">
        <div class="swiper-wrapper">
            <?php foreach ($complainList as $k => $v): ?>
                <div class="swiper-slide">
                    <div class="slide-img">
                        <?php if ($v['pic']): ?>
                            <img src="<?= STATIC_URL . $v['pic'] ?>">
                        <?php else: ?>
                            <img src="<?= IMG_URL ?>/yc-system-item-swiper.jpg">
                        <?php endif; ?>

                        <div class="slide-des">
                            <h2><i><img src="<?= IMG_URL ?>/yc-partner-symbol.png"></i><?= $v['title'] ?></h2>
                            <p><?= $v['content'] ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <!-- Add Pagination -->
        <div class="swiper-pagination"></div>
        <!-- Add Arrows -->
        <?php if (count($complainList) > 1): ?>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        <?php endif; ?>
    </div>
</div>
<div class="common-project-wrap">
    <p class="fn-clear project-scene-title">
        <span class="fn-left">产品推荐</span>
        <a href="<?php echo Url::to(['product/index']) ?>" class="fn-right more-btn project-btn">MORE →</a>
    </p>
    <ul class="solution-project-item">
        <?php foreach ($productList as $k => $v): ?>
            <li>
                <a href="<?php echo Url::to(['product/prodetail', 'id' => $v['id']]) ?>">
                    <img src="<?= STATIC_URL . $v['pic'] ?>">
                </a>
                <p><?= $v['title'] ?></p>
                <p><?= $v['en_lang'] ?></p>
            </li>
        <?php endforeach; ?>
    </ul>
    <p class="fn-clear project-scene-title">
        <span class="fn-left">应用场景推荐</span>
        <a href="应用场景.html" class="fn-right more-btn scene-btn">MORE →</a>
    </p>
    <ul class="scene-item">
        <?php foreach ($sceneList as $k => $v): ?>
            <li>
                <a href="应用场景.html">
                    <p><?= $v['title'] ?></p>
                    <div>
                        <p>
                            <span><i><img src="<?= IMG_URL ?>/yc-scene-goods.png"></i>适用产品</span>
                            <span><?= $v['product'] ?></span>
                        </p>
                        <p>
                            <span><i><img src="<?= IMG_URL ?>/yc-scene-user.png"></i>适用对象</span>
                            <span><?= $v['obj'] ?></span>
                        </p>
                    </div>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
</div>
<?php $this->endBody() ?>

<script>
    var swiper = new Swiper('.swiper-container', {
        pagination: '.swiper-pagination',
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        slidesPerView: 2,
        paginationClickable: true,
        loop: <?= count($complainList) > 2?'true':'false';?>,
        centeredSlides: true,
        spaceBetween: 30,
        breakpoints: {
            668: {
                slidesPerView: 1,
            }
        }
//      freeMode: true
    });

    $(function () {
        var productListJson = <?= json_encode($productList);?>;
        for (var i = 1; i < $('.solution-project-item>li').length + 1; i++) {
            $('.solution-project-item li:nth-of-type(' + i + ')').hover(function () {
                var _index = $(this).index() + 1;
                $(this).find('img').attr('src', productListJson[_index]['pic_home'])
            }, function () {
                var _index = $(this).index() + 1;
                $(this).find('img').attr('src', productListJson[_index]['pic'])
            })
        }

        $('.scene-item').on('click', 'li', function () {
            var par = '应用场景';
            jumpFanc(par);
        })

        $('.scene-btn').on('click', function () {
            var par = '应用场景';
            jumpFanc(par);
        })
    })

    function jumpFanc(par) {
        var nav_li = $('.nav-head>li', window.parent.document);
        nav_li.removeClass('nav-actived');
        for (var i = 0; i < nav_li.length; i++) {
            if (nav_li.eq(i).children('a').text() == par) {
                nav_li.eq(i).addClass('nav-actived')
            }
        }
    }
</script>
</body>
</html>
<?php $this->endPage() ?>
